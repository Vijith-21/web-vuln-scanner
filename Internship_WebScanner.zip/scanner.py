import requests
from urllib.parse import urlparse, urlunparse, parse_qs, urlencode
from bs4 import BeautifulSoup
import html
import os
import datetime

USER_AGENT = "InternshipScanner/1.0 (+https://example.com/)"

class Scanner:
    def __init__(self, timeout=10):
        self.timeout = timeout
        self.headers = {"User-Agent": USER_AGENT}

    def _safe_get(self, url):
        try:
            r = requests.get(url, headers=self.headers, timeout=self.timeout)
            return r
        except Exception as e:
            return None

    def check_headers(self, response):
        # Basic security headers to check
        need = [
            "Strict-Transport-Security",
            "Content-Security-Policy",
            "X-Frame-Options",
            "X-Content-Type-Options",
            "Referrer-Policy",
            "Permissions-Policy"
        ]
        res = {}
        if response is None:
            for h in need:
                res[h] = {"present": False, "value": None}
            return res
        for h in need:
            val = response.headers.get(h)
            res[h] = {"present": bool(val), "value": val}
        return res

    def test_reflected_xss(self, url):
        payload = "<script>alert('xss')</script>"
        return self._test_reflection(url, payload, "XSS")

    def test_sql_injection(self, url):
        payload = "' OR '1'='1"
        return self._test_reflection(url, payload, "SQLi")

    def _test_reflection(self, url, payload, tname):
        # If URL has no query params, add one param "q" with payload.
        p = urlparse(url)
        qs = parse_qs(p.query)
        if len(qs) == 0:
            qs = {"scanparam": [payload]}
        else:
            # inject payload to first param
            first = next(iter(qs))
            qs[first] = [payload]
        new_query = urlencode({k: v[0] for k,v in qs.items()})
        new_url = urlunparse((p.scheme, p.netloc, p.path, p.params, new_query, p.fragment))
        resp = self._safe_get(new_url)
        result = {"tested_url": new_url, "response": None, "reflected": False}
        if resp is None:
            return result
        body = resp.text
        # crude reflection check
        if payload in body:
            result["reflected"] = True
        result["response"] = {"status_code": resp.status_code, "len": len(body)}
        return result

    def fingerprint(self, response):
        tech = {"server": None, "x-powered-by": None}
        if response is None:
            return tech
        tech["server"] = response.headers.get("Server")
        tech["x-powered-by"] = response.headers.get("X-Powered-By")
        return tech

    def scan(self, url, outdir):
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = os.path.join(outdir, f"report_{timestamp}.html")

        base_resp = self._safe_get(url)
        headers_check = self.check_headers(base_resp)
        fp = self.fingerprint(base_resp)
        xss = self.test_reflected_xss(url)
        sqli = self.test_sql_injection(url)

        # Build simple HTML report
        html_parts = []
        html_parts.append(f"<h1>Scan Report for {html.escape(url)}</h1>")
        html_parts.append(f"<p>Scan time: {timestamp}</p>")

        html_parts.append("<h2>Reachability</h2>")
        if base_resp is None:
            html_parts.append("<p style='color:red;'>Target unreachable or request failed.</p>")
        else:
            html_parts.append(f"<p>Status Code: {base_resp.status_code}</p>")

        html_parts.append("<h2>Security Headers</h2><ul>")
        for h,v in headers_check.items():
            if v['present']:
                html_parts.append(f"<li>{h}: {html.escape(str(v['value']))}</li>")
            else:
                html_parts.append(f"<li style='color:darkorange;'>{h}: <strong>Missing</strong></li>")
        html_parts.append("</ul>")

        html_parts.append("<h2>Technology Fingerprint</h2><ul>")
        for k,val in fp.items():
            html_parts.append(f"<li>{k}: {html.escape(str(val))}</li>")
        html_parts.append("</ul>")

        html_parts.append("<h2>Simple Vulnerability Tests</h2>")
        html_parts.append("<h3>Reflected XSS Test</h3>")
        if xss["response"] is None:
            html_parts.append("<p>Test failed (no response).</p>")
        else:
            if xss["reflected"]:
                html_parts.append(f"<p style='color:red;'>Payload was reflected — possible reflected XSS.<br>Tested URL: {html.escape(xss['tested_url'])}</p>")
            else:
                html_parts.append(f"<p>No reflection detected (status {xss['response']['status_code']}).</p>")

        html_parts.append("<h3>Basic SQL Injection Test</h3>")
        if sqli["response"] is None:
            html_parts.append("<p>Test failed (no response).</p>")
        else:
            if sqli["reflected"]:
                html_parts.append(f"<p style='color:red;'>Payload was reflected — check for injection or error-based feedback.<br>Tested URL: {html.escape(sqli['tested_url'])}</p>")
            else:
                html_parts.append(f"<p>No obvious reflection detected (status {sqli['response']['status_code']}).</p>")

        html_parts.append("<h2>Notes & Recommendations</h2>")
        html_parts.append("<ul>")
        html_parts.append("<li>Only basic, non-intrusive checks were performed.</li>")
        html_parts.append("<li>Add Content-Security-Policy and HSTS to harden the app.</li>")
        html_parts.append("<li>Use parameterized queries on server-side to prevent SQL injection.</li>")
        html_parts.append("<li>Sanitize and encode user inputs to prevent XSS.</li>")
        html_parts.append("</ul>")

        # Write report
        with open(report_file, "w", encoding="utf-8") as f:
            f.write("<html><head><meta charset='utf-8'><title>Scan Report</title></head><body>")
            f.write("".join(html_parts))
            f.write("</body></html>")
        return report_file