# Internship Project — Simple Web Application Vulnerability Scanner

**Purpose:** A ready-to-run, minimal web scanner that performs non-intrusive checks:
- Checks for common security headers
- Performs simple reflected XSS detection (by checking reflection of a payload)
- Performs a basic SQLi reflection test (non-intrusive)
- Generates an HTML report

**Important — Legal Notice**
Only scan websites you own or have explicit permission to test. Unauthorized scanning can be illegal and unethical.

## Setup (Windows / Linux / macOS)

1. Install Python 3.8+.
2. Create a virtual environment (recommended):
   ```
   python -m venv venv
   source venv/bin/activate   # Linux / macOS
   venv\Scripts\activate      # Windows
   ```
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Run the scanner:
   ```
   python main.py --url "https://example.com" --output output
   ```
5. Open the generated HTML file in the `output/` folder (report_YYYYMMDD_HHMMSS.html).

## Files included
- `main.py` — entrypoint
- `scanner.py` — scanner logic
- `requirements.txt` — dependencies
- `README.md` — this file

## Notes for submission
- Attach the entire project folder or zip it.
- Include a short cover note mentioning: tested on `https://example.com` (or a demo/test host), output HTML attached.

Good luck — this is intentionally minimal and safe for an internship submission.