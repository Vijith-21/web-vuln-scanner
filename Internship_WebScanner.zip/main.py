#!/usr/bin/env python3
"""
Simple Web Application Vulnerability Scanner (Internship-ready)

Usage:
    python main.py --url "https://example.com"

Disclaimer:
    Only scan websites you own or have explicit permission to test.
    This tool performs non-intrusive checks (headers, simple reflected XSS/SQLi tests).
"""

import argparse
import os
from scanner import Scanner

def main():
    parser = argparse.ArgumentParser(description="Simple Web App Vulnerability Scanner")
    parser.add_argument("--url", required=True, help="Target URL (include http/https).")
    parser.add_argument("--output", default="output", help="Output folder for reports.")
    parser.add_argument("--timeout", type=int, default=10, help="Request timeout in seconds.")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)
    s = Scanner(timeout=args.timeout)
    report_path = s.scan(args.url, args.output)
    print(f"Scan complete. Report saved to: {report_path}")

if __name__ == "__main__":
    main()